package model;

public class CallModel {
    private String remoteIP;
    private int tcpPort = 8081;
    private int udpPort = 9091;
    private boolean isCalling = false;
    private boolean isMuted = false;

    // Getters and Setters
    public String getRemoteIP() { return remoteIP; }
    public void setRemoteIP(String remoteIP) { this.remoteIP = remoteIP; }

    public int getTcpPort() { return tcpPort; }
    public void setTcpPort(int tcpPort) { this.tcpPort = tcpPort; }

    public int getUdpPort() { return udpPort; }
    public void setUdpPort(int udpPort) { this.udpPort = udpPort; }

    public boolean isCalling() { return isCalling; }
    public void setCalling(boolean calling) { isCalling = calling; }

    public boolean isMuted() { return isMuted; }
    public void setMuted(boolean muted) { isMuted = muted; }
}