package controller;

import model.CallModel;
import model.NetworkModel;

import javax.swing.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerController {

    private ServerSocket serverSocket;
    private boolean running = false;

    private CallController callController;
    private final NetworkModel networkModel;
    private final CallModel callModel;
    private final AudioController audioController;

    private static final String AUDIO_DIR = "received_audio_messages";

    public ServerController(NetworkModel networkModel, CallModel callModel, AudioController audioController) {
        this.networkModel = networkModel;
        this.callModel = callModel;
        this.audioController = audioController;

        File dir = new File(AUDIO_DIR);
        if (!dir.exists()) dir.mkdirs();
    }

    public void setCallController(CallController callController) {
        this.callController = callController;
        System.out.println("ServerController: CallController已设置");
    }

    public boolean startServer(int port) {
        if (running) return true;

        try {
            serverSocket = new ServerSocket(port, 50, InetAddress.getByName("0.0.0.0"));
            running = true;
            new Thread(this::acceptLoop, "TCP-Server-AcceptLoop").start();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                new Thread(() -> handleClient(client)).start();
            } catch (Exception ignored) {}
        }
    }

    private void handleClient(Socket socket) {

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            String command = in.readLine();

            if (command == null) {
                socket.close();
                return;
            }

            switch (command.trim()) {
                case "DIAL_REQUEST":
                    handleDialRequest(socket, in);
                    break;

                case "AUDIO_MESSAGE":
                    handleAudioMessage(socket, in);
                    break;

                default:
                    socket.close();
            }

        } catch (Exception e) {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    /**
     * 处理来电请求
     */
    private void handleDialRequest(Socket socket, BufferedReader in) {

        PrintWriter out;
        try {
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
        } catch (Exception e) {
            try { socket.close(); } catch (Exception ignored) {}
            return;
        }

        String remoteIP = socket.getInetAddress().getHostAddress();

        SwingUtilities.invokeLater(() -> {
            int choice = JOptionPane.showConfirmDialog(
                    null,
                    "来自 " + remoteIP + " 的来电，是否接听？",
                    "来电提示",
                    JOptionPane.YES_NO_OPTION
            );

            if (choice == JOptionPane.YES_OPTION) {

                // **发送接听响应，但绝不能关闭 socket**
                try {
                    out.println("DIAL_ACCEPT");
                    out.flush();
                } catch (Exception e) {
                    System.out.println("发送接受响应失败：" + e.getMessage());
                    try { socket.close(); } catch (Exception ignored) {}
                    return;
                }

                // 把 socket 交给 CallController
                if (callController != null) {
                    callController.handleIncomingCallAccepted(socket, remoteIP);
                } else {
                    try { socket.close(); } catch (Exception ignored) {}
                }

            } else {
                try {
                    out.println("DIAL_REJECT");
                    out.flush();
                } catch (Exception ignored) {}

                try { socket.close(); } catch (Exception ignored) {}
            }
        });
    }


    /**
     * 处理音频文件
     */
    private void handleAudioMessage(Socket socket, BufferedReader in) {

        try {

            String fileName = in.readLine();
            String sizeStr = in.readLine();

            if (fileName == null || sizeStr == null) {
                socket.close();
                return;
            }

            long size = Long.parseLong(sizeStr);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            File output = new File(AUDIO_DIR, timestamp + "_" + fileName);

            FileOutputStream out = new FileOutputStream(output);
            InputStream ins = socket.getInputStream();
            byte[] buffer = new byte[4096];

            long readTotal = 0;
            int len;

            while (readTotal < size && (len = ins.read(buffer)) != -1) {
                out.write(buffer, 0, len);
                readTotal += len;
            }

            out.close();
            socket.close();

            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(
                        null,
                        "收到音频消息：" + output.getName(),
                        "新消息",
                        JOptionPane.INFORMATION_MESSAGE
                );
            });

        } catch (Exception e) {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    public void stopServer() {
        running = false;
        try { serverSocket.close(); } catch (Exception ignored) {}
    }

    public boolean isServerRunning() {
        return running;
    }
}
