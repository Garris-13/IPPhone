package controller;

import model.*;
import view.*;
import util.*;

import javax.swing.*;
import java.io.File;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * 修复版 CallController（与项目中现有 MainView/AudioController/ServerController 接口匹配）
 * 要点：
 *  - 使用 mainView.addConnectButtonListener / getRemoteIP 等真实方法名
 *  - 拨号时发送 "DIAL_REQUEST" 并阻塞 readLine() 等待响应（超时保护）
 *  - 接听端不会在发送 DIAL_ACCEPT 后关闭 socket，而是将 socket 交给 CallController 继续管理
 *  - 接听/拨号成功后创建 DatagramSocket 并启动 audioController 的音频线程
 *  - 结束通话时正确关闭 UDP/TCP socket，并停止 audioController
 */
public class CallController {

    private final CallModel callModel;
    private final NetworkModel networkModel;
    private final MainView mainView;
    private final DialingView dialingView;
    private final CallView callView;
    private final AudioController audioController;
    private final ServerController serverController;

    public CallController(CallModel callModel,
                          NetworkModel networkModel,
                          MainView mainView,
                          DialingView dialingView,
                          CallView callView,
                          javax.swing.JPanel mainPanel,
                          java.awt.CardLayout cardLayout) {
        this.callModel = callModel;
        this.networkModel = networkModel;
        this.mainView = mainView;
        this.dialingView = dialingView;
        this.callView = callView;

        // 使用项目中已有的 AudioController 构造方式
        this.audioController = new AudioController(new AudioModel(), networkModel);

        // 创建 server controller 并把自己注册进去（ServerController 会回调 handleIncomingCallAccepted）
        this.serverController = new ServerController(networkModel, callModel, audioController);
        this.serverController.setCallController(this);

        // 绑定 UI 事件（使用你项目里的方法名）
        bindUI(mainPanel, cardLayout);
        // 自动启动服务器（如果需要）
        boolean started = this.serverController.startServer(callModel.getTcpPort());
        if (!started) {
            mainView.showError("服务器启动失败，可能端口被占用");
        }
    }

    private void bindUI(javax.swing.JPanel mainPanel, java.awt.CardLayout cardLayout) {
        // 连接（拨号）按钮
        mainView.addConnectButtonListener(e -> {
            String remote = mainView.getRemoteIP();
            if (remote == null || remote.trim().isEmpty()) {
                mainView.showError("请输入目标IP地址");
                return;
            }
            callModel.setRemoteIP(remote.trim());
            // 切换到拨号页面并执行拨号
            cardLayout.show(mainPanel, "DIALING");
            dialingView.setStatus("正在拨号到 " + callModel.getRemoteIP() + " ...");
            startDialing(mainPanel, cardLayout);
        });

        // 录音按钮（MainView 中的录音控制）
        mainView.addRecordButtonListener(e -> {
            if (!audioController.isRecording()) {
                boolean ok = audioController.startRecording();
                if (ok) mainView.setRecordingState(true, false);
                else mainView.showError("无法开始录音");
            } else {
                File f = audioController.stopRecording();
                mainView.setRecordingState(false, f != null && f.exists());
                if (f != null) {
                    mainView.showInfo("录音已保存: " + f.getName());
                }
            }
        });

        // 切换服务器启动/停止
        mainView.addServerToggleListener(e -> {
            if (serverController.isServerRunning()) {
                serverController.stopServer();
                mainView.setServerState(false);
                mainView.showInfo("服务器已停止");
            } else {
                boolean ok = serverController.startServer(callModel.getTcpPort());
                if (ok) {
                    mainView.setServerState(true);
                    mainView.showInfo("服务器已启动");
                } else {
                    mainView.showError("服务器启动失败");
                }
            }
        });

        // 拨号界面：取消按钮
        dialingView.addCancelButtonListener(e -> {
            // 取消拨号，若存在临时 tcp socket 则关闭
            try {
                Socket s = networkModel.getTcpSocket();
                if (s != null && !s.isClosed()) s.close();
            } catch (Exception ignored) {
            }
            cardLayout.show(mainPanel, "MAIN");
        });

        // 通话界面：静音 / 结束通话
        callView.addMuteButtonListener(e -> {
            boolean muted = !audioController.isMuted();
            audioController.setMuted(muted);
            callView.updateMuteButton(muted);
        });

        callView.addEndCallButtonListener(e -> {
            endCall(mainPanel, cardLayout);
        });
    }

    /**
     * 拨号流程（新线程）
     */
    private void startDialing(javax.swing.JPanel mainPanel, java.awt.CardLayout cardLayout) {
        new Thread(() -> {
            Socket socket = null;
            try {
                socket = new Socket();
                socket.connect(new InetSocketAddress(callModel.getRemoteIP(), callModel.getTcpPort()), 8000);
                socket.setSoTimeout(20000); // 20s 读超时

                // 发送拨号请求
                java.io.PrintWriter out = new java.io.PrintWriter(
                        new java.io.OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
                java.io.BufferedReader in = new java.io.BufferedReader(
                        new java.io.InputStreamReader(socket.getInputStream(), "UTF-8"));

                out.println("DIAL_REQUEST");
                out.flush();

                String resp = in.readLine();
                System.out.println("收到对方响应: " + resp);

                if (resp == null) {
                    // 表示对端已经关闭连接
                    SwingUtilities.invokeLater(() -> {
                        mainView.showInfo("对方无响应或已关闭连接");
                        cardLayout.show(mainPanel, "MAIN");
                    });
                    try { socket.close(); } catch (Exception ignored) {}
                    return;
                }

                if ("DIAL_ACCEPT".equals(resp.trim())) {
                    // 保存 tcp socket，不要关闭
                    networkModel.setTcpSocket(socket);

                    // 切换到通话页面
                    SwingUtilities.invokeLater(() -> {
                        callView.setStatus("已接通：" + callModel.getRemoteIP());
                        cardLayout.show(mainPanel, "CALL");
                    });

                    // 建立 UDP socket 并启动音频流
                    DatagramSocket udp = new DatagramSocket();
                    networkModel.setUdpSocket(udp);
                    callModel.setCalling(true);

                    audioController.startAudioStreaming(callModel.getRemoteIP(), callModel.getUdpPort());

                    return;
                } else if ("DIAL_REJECT".equals(resp.trim())) {
                    SwingUtilities.invokeLater(() -> {
                        mainView.showInfo("对方拒绝了通话");
                        cardLayout.show(mainPanel, "MAIN");
                    });
                    try { socket.close(); } catch (Exception ignored) {}
                    return;
                } else {
                    SwingUtilities.invokeLater(() -> {
                        mainView.showInfo("收到未知响应: " + resp);
                        cardLayout.show(mainPanel, "MAIN");
                    });
                    try { socket.close(); } catch (Exception ignored) {}
                    return;
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                SwingUtilities.invokeLater(() -> {
                    mainView.showError("拨号失败: " + ex.getMessage());
                    cardLayout.show(mainPanel, "MAIN");
                });
                try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            }
        }, "Dialing-Thread").start();
    }

    /**
     * ServerController 在接听时会调用该方法，把已接听的 socket 交给 CallController
     */
    public void handleIncomingCallAccepted(Socket acceptedSocket, String remoteIP) {
        try {
            networkModel.setTcpSocket(acceptedSocket);

            // 切换界面并启动 UDP 音频
            SwingUtilities.invokeLater(() -> callView.setStatus("与 " + remoteIP + " 通话中..."));
            DatagramSocket udp = new DatagramSocket();
            networkModel.setUdpSocket(udp);
            callModel.setCalling(true);

            audioController.startAudioStreaming(remoteIP, callModel.getUdpPort());
        } catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> mainView.showError("建立通话失败: " + e.getMessage()));
        }
    }

    /**
     * 结束通话：关闭 udp/tcp socket，停止音频
     */
    private void endCall(javax.swing.JPanel mainPanel, java.awt.CardLayout cardLayout) {
        callModel.setCalling(false);

        try {
            DatagramSocket udp = networkModel.getUdpSocket();
            if (udp != null) udp.close();
        } catch (Exception ignored) {}

        try {
            Socket s = networkModel.getTcpSocket();
            if (s != null) s.close();
        } catch (Exception ignored) {}

        networkModel.setTcpSocket(null);
        networkModel.setUdpSocket(null);

        audioController.stopAudio(); // 使用项目中已有方法名

        SwingUtilities.invokeLater(() -> cardLayout.show(mainPanel, "MAIN"));
    }

    /**
     * 发送音频消息（UI 调用）
     */
    public void sendAudioMessage() {
        File f = audioController.getRecordedFile();
        if (f == null || !f.exists()) {
            mainView.showError("没有录音文件可发送");
            return;
        }
        audioController.sendAudioMessage(callModel.getRemoteIP(), f);
        callView.appendMessage("本机", "发送了音频消息");
    }
}
