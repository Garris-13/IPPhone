package controller;

import model.*;
import javax.sound.sampled.*;
import java.io.*;
import java.net.*;

public class AudioController {
    private AudioModel audioModel;
    private NetworkModel networkModel;
    private boolean isStreaming = false;
    private boolean isMuted = false;
    private boolean isRecording = false;
    private TargetDataLine recordingLine;
    private File currentRecordingFile;
    private AudioInputStream recordingStream;

    public AudioController(AudioModel audioModel, NetworkModel networkModel) {
        this.audioModel = audioModel;
        this.networkModel = networkModel;
    }

    // 实时音频通话相关方法
//    public void startAudioStreaming(String remoteIP, int udpPort) {
//        isStreaming = true;
//        new Thread(() -> sendAudio(remoteIP, udpPort)).start();
//        new Thread(this::receiveAudio).start();
//    }

    public void stopAudioStreaming() {
        isStreaming = false;
    }

    public void setMuted(boolean muted) {
        isMuted = muted;
    }

    // 音频消息相关方法 - 完善版本
    public boolean startRecording() {
        if (isRecording) {
            return false;
        }

        try {
            isRecording = true;
            AudioFormat format = audioModel.getAudioFormat();
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            recordingLine = (TargetDataLine) AudioSystem.getLine(info);

            recordingLine.open(format);
            recordingLine.start();

            // 创建临时文件保存录音
            currentRecordingFile = File.createTempFile("audio_message_", ".wav");

            // 创建音频输入流
            recordingStream = new AudioInputStream(recordingLine);

            // 在新线程中写入文件，避免阻塞UI
            new Thread(() -> {
                try {
                    AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;
                    AudioSystem.write(recordingStream, fileType, currentRecordingFile);
                } catch (IOException e) {
                    System.err.println("录音文件写入失败: " + e.getMessage());
                }
            }).start();

            return true;

        } catch (LineUnavailableException e) {
            System.err.println("音频线路不可用: " + e.getMessage());
            isRecording = false;
            return false;
        } catch (IOException e) {
            System.err.println("录音文件创建失败: " + e.getMessage());
            isRecording = false;
            return false;
        } catch (Exception e) {
            System.err.println("录音启动失败: " + e.getMessage());
            isRecording = false;
            return false;
        }
    }

    public File stopRecording() {
        if (!isRecording || recordingLine == null) {
            return null;
        }

        isRecording = false;

        try {
            recordingLine.stop();
            recordingLine.close();
            recordingLine = null;

            // 等待文件写入完成
            Thread.sleep(100);

            // 检查文件是否有效
            if (currentRecordingFile != null && currentRecordingFile.exists() &&
                    currentRecordingFile.length() > 0) {
                return currentRecordingFile;
            } else {
                return null;
            }

        } catch (Exception e) {
            System.err.println("停止录音失败: " + e.getMessage());
            return null;
        }
    }

    public boolean isRecording() {
        return isRecording;
    }

    public File getRecordedFile() {
        return currentRecordingFile;
    }

    public boolean hasRecordedAudio() {
        return currentRecordingFile != null && currentRecordingFile.exists() &&
                currentRecordingFile.length() > 0;
    }

    public void sendAudioMessage(String remoteIP, File audioFile) {
        new Thread(() -> {
            Socket socket = null;
            FileInputStream fileIn = null;
            try {
                socket = new Socket(remoteIP, audioModel.getTcpPort());
                socket.setSoTimeout(30000); // 30秒超时

                OutputStream out = socket.getOutputStream();
                PrintWriter writer = new PrintWriter(out, true);

                // 发送消息类型
                writer.println("AUDIO_MESSAGE");

                // 发送文件名和大小
                String fileName = "audio_message.wav";
                writer.println(fileName);
                writer.println(audioFile.length());

                // 发送文件内容
                fileIn = new FileInputStream(audioFile);
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalSent = 0;

                while ((bytesRead = fileIn.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                    totalSent += bytesRead;

                    // 可选：显示发送进度
                    if (audioFile.length() > 0) {
                        int progress = (int) ((totalSent * 100) / audioFile.length());
                        System.out.println("发送进度: " + progress + "%");
                    }
                }

                out.flush();
                System.out.println("音频消息发送成功: " + audioFile.getName() +
                        ", 大小: " + totalSent + " 字节");

            } catch (UnknownHostException e) {
                System.err.println("未知主机: " + remoteIP + " - " + e.getMessage());
            } catch (IOException e) {
                System.err.println("发送音频消息失败: " + e.getMessage());
            } finally {
                // 清理资源
                if (fileIn != null) {
                    try {
                        fileIn.close();
                    } catch (IOException e) {
                        System.err.println("关闭文件输入流失败: " + e.getMessage());
                    }
                }
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        System.err.println("关闭socket失败: " + e.getMessage());
                    }
                }
            }
        }).start();
    }

    public void cleanupRecording() {
        if (currentRecordingFile != null && currentRecordingFile.exists()) {
            // 可选：删除临时文件
            // currentRecordingFile.delete();
        }
        currentRecordingFile = null;
    }

    // 实时音频发送（保持不变）
    private void sendAudio(String remoteIP, int udpPort) {
        TargetDataLine line = null;
        try {
            AudioFormat format = audioModel.getAudioFormat();
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            line = (TargetDataLine) AudioSystem.getLine(info);

            line.open(format);
            line.start();

            byte[] buffer = new byte[1024];
            InetAddress remoteAddress = InetAddress.getByName(remoteIP);

            while (isStreaming) {
                if (!isMuted) {
                    int bytesRead = line.read(buffer, 0, buffer.length);
                    if (bytesRead > 0) {
                        DatagramPacket packet = new DatagramPacket(
                                buffer, bytesRead, remoteAddress, udpPort);
                        networkModel.getUdpSocket().send(packet);
                    }
                } else {
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }

        } catch (Exception e) {
            if (isStreaming) {
                System.err.println("音频发送错误: " + e.getMessage());
            }
        } finally {
            if (line != null) {
                line.stop();
                line.close();
            }
        }
    }

    // 实时音频接收（保持不变）
    private void receiveAudio() {
        SourceDataLine line = null;
        try {
            AudioFormat format = audioModel.getAudioFormat();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            line = (SourceDataLine) AudioSystem.getLine(info);

            line.open(format);
            line.start();

            byte[] buffer = new byte[1024];

            while (isStreaming) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                networkModel.getUdpSocket().receive(packet);
                line.write(packet.getData(), 0, packet.getLength());
            }

        } catch (Exception e) {
            if (isStreaming) {
                System.err.println("音频接收错误: " + e.getMessage());
            }
        } finally {
            if (line != null) {
                line.stop();
                line.close();
            }
        }
    }


    // 获取音频状态
    public boolean isStreaming() {
        return isStreaming;
    }

    public boolean isMuted() {
        return isMuted;
    }
    // =======================
//  新增：停止音频线程方法
// =======================
    private Thread audioSendThread;
    private Thread audioReceiveThread;
    private volatile boolean runningAudio = false;

    public void startAudioStreaming(String remoteIP, int udpPort) {
        runningAudio = true;

        // 原你已有的逻辑，这里只是示例
        audioSendThread = new Thread(() -> {
            try {
                // 发送音频循环
                while (runningAudio) {
                    // 原来的发送代码……
                }
            } catch (Exception ignored) {}
        }, "Audio-Send");
        audioSendThread.start();

        audioReceiveThread = new Thread(() -> {
            try {
                // 接收音频循环
                while (runningAudio) {
                    // 原来的接收代码……
                }
            } catch (Exception ignored) {}
        }, "Audio-Recv");
        audioReceiveThread.start();
    }

    /** 停止音频发送/接收线程 */
    public void stopAudio() {
        runningAudio = false;

        try { if (audioSendThread != null) audioSendThread.join(200); } catch (Exception ignored) {}
        try { if (audioReceiveThread != null) audioReceiveThread.join(200); } catch (Exception ignored) {}
    }

}