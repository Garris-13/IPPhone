import controller.CallController;
import model.CallModel;
import model.NetworkModel;
import view.MainView;
import view.DialingView;
import view.CallView;
import util.FontUtils;
import javax.swing.*;
import java.awt.*;

public class IPPhone extends JFrame {
    private CallModel callModel;
    private NetworkModel networkModel;
    private MainView mainView;
    private DialingView dialingView;
    private CallView callView;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private CallController callController;

    public IPPhone() {
        // 设置中文Look and Feel
        setChineseLookAndFeel();
        initializeModels();
        initializeViews();
        initializeController();
        setupFrame();
    }

    private void setChineseLookAndFeel() {
        try {
            // 使用系统默认的Look and Feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            // 设置全局字体
            Font chineseFont = FontUtils.getChineseFont(14f);
            UIManager.put("Button.font", chineseFont);
            UIManager.put("Label.font", chineseFont);
            UIManager.put("TextField.font", chineseFont);
            UIManager.put("ComboBox.font", chineseFont);
            UIManager.put("OptionPane.messageFont", chineseFont);
            UIManager.put("OptionPane.buttonFont", chineseFont);

        } catch (Exception e) {
            System.err.println("设置Look and Feel失败: " + e.getMessage());
            // 忽略错误，使用默认设置
        }
    }

    private void initializeModels() {
        callModel = new CallModel();
        networkModel = new NetworkModel();
    }

    private void initializeViews() {
        // 获取本地IP并传递给各个视图
        String localIP = networkModel.getLocalIP();

        mainView = new MainView(localIP);
        dialingView = new DialingView(localIP);
        callView = new CallView(localIP);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(mainView, "MAIN");
        mainPanel.add(dialingView, "DIALING");
        mainPanel.add(callView, "CALL");
    }

    private void initializeController() {
        callController = new CallController(
                callModel, networkModel, mainView, dialingView, callView,
                mainPanel, cardLayout
        );
    }

    private void setupFrame() {
        setTitle("IP Phone - 本地IP: " + networkModel.getLocalIP());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 350);
        setLocationRelativeTo(null);
        add(mainPanel);
        cardLayout.show(mainPanel, "MAIN");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            IPPhone phone = new IPPhone();
            phone.setVisible(true);
//
//            // 添加服务器状态检查
//            Timer timer = new Timer(2000, e -> {
//                // 这里可以添加状态检查逻辑
//                System.out.println("应用程序运行中...");
//            });
//            timer.start();
        });
    }
}