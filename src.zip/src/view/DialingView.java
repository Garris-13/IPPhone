package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import util.FontUtils;

public class DialingView extends JPanel {
    private JLabel statusLabel;
    private JButton cancelButton;
    private JLabel localIPLabel;

    public DialingView(String localIP) {
        initializeUI(localIP);
    }

    private void initializeUI(String localIP) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        // 创建中文字体
        Font normalFont = FontUtils.getChineseFont(14f);
        Font smallFont = FontUtils.getChineseFont(12f);
        Font titleFont = FontUtils.getChineseBoldFont(18f);
        Font statusFont = FontUtils.getChineseFont(16f);

        // 顶部面板 - 显示本地IP
        JPanel topPanel = new JPanel(new BorderLayout());
        localIPLabel = new JLabel("本地IP: " + localIP, JLabel.LEFT);
        localIPLabel.setFont(smallFont);
        localIPLabel.setForeground(Color.BLUE);
        topPanel.add(localIPLabel, BorderLayout.WEST);

        JLabel titleLabel = new JLabel("正在拨号", JLabel.CENTER);
        titleLabel.setFont(titleFont);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // 中心面板 - 状态显示
        statusLabel = new JLabel("正在拨号...", JLabel.CENTER);
        statusLabel.setFont(statusFont);
        add(statusLabel, BorderLayout.CENTER);

        // 底部面板 - 取消按钮
        cancelButton = new JButton("取消");
        cancelButton.setFont(normalFont);
        add(cancelButton, BorderLayout.SOUTH);
    }

    // Action listeners
    public void addCancelButtonListener(ActionListener listener) {
        cancelButton.addActionListener(listener);
    }

    // Status update methods
    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    // 更新本地IP显示
    public void updateLocalIP(String localIP) {
        localIPLabel.setText("本地IP: " + localIP);
    }
}