package view;// 在 view.CallView 中，替换/修改初始化 UI，添加 messageArea
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import util.FontUtils;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CallView extends JPanel {
    private JLabel statusLabel;
    private JButton muteButton;
    private JButton endCallButton;
    private JLabel localIPLabel;
    private boolean isMuted = false;
    private JTextArea messageArea;

    public CallView(String localIP) {
        initializeUI(localIP);
    }

    private void initializeUI(String localIP) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        Font normalFont = FontUtils.getChineseFont(14f);
        Font smallFont = FontUtils.getChineseFont(12f);
        Font titleFont = FontUtils.getChineseBoldFont(18f);
        Font statusFont = FontUtils.getChineseFont(16f);

        JPanel topPanel = new JPanel(new BorderLayout());
        localIPLabel = new JLabel("本地IP: " + localIP, JLabel.LEFT);
        localIPLabel.setFont(smallFont);
        localIPLabel.setForeground(Color.BLUE);
        topPanel.add(localIPLabel, BorderLayout.WEST);

        JLabel titleLabel = new JLabel("通话中", JLabel.CENTER);
        titleLabel.setFont(titleFont);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // 中心：状态 + 消息区域
        JPanel centerPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel("通话中...", JLabel.CENTER);
        statusLabel.setFont(statusFont);
        centerPanel.add(statusLabel, BorderLayout.NORTH);

        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);
        messageArea.setFont(normalFont);
        JScrollPane scroll = new JScrollPane(messageArea);
        scroll.setPreferredSize(new Dimension(300, 150));
        centerPanel.add(scroll, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        muteButton = new JButton("静音");
        muteButton.setFont(normalFont);

        endCallButton = new JButton("结束通话");
        endCallButton.setFont(normalFont);

        buttonPanel.add(muteButton);
        buttonPanel.add(endCallButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public void addMuteButtonListener(ActionListener listener) {
        muteButton.addActionListener(listener);
    }

    public void addEndCallButtonListener(ActionListener listener) {
        endCallButton.addActionListener(listener);
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    public void updateMuteButton(boolean muted) {
        isMuted = muted;
        muteButton.setText(muted ? "取消静音" : "静音");
    }

    public boolean isMuted() {
        return isMuted;
    }

    public void updateLocalIP(String localIP) {
        localIPLabel.setText("本地IP: " + localIP);
    }

    // 新增：往消息区追加一行（带时间）
    public void appendMessage(String who, String msg) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String ts = sdf.format(new Date());
        messageArea.append("[" + ts + "] " + who + ": " + msg + "\n");
        messageArea.setCaretPosition(messageArea.getDocument().getLength());
    }
}
