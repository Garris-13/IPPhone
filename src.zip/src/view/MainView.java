//package view;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionListener;
//import util.FontUtils;
//
//public class MainView extends JPanel {
//    private JTextField ipField;
//    private JComboBox<String> modeComboBox;
//    private JButton connectButton;
//    private JLabel localIPLabel;
//    private JButton recordButton;
//    private JLabel recordingStatusLabel;
//    private boolean isRecording = false;
//    private boolean hasRecorded = false; // 新增：标记是否有录制完成的音频
//
//    public MainView(String localIP) {
//        initializeUI(localIP);
//    }
//
//    private void initializeUI(String localIP) {
//        setLayout(new BorderLayout());
//        setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
//
//        Font normalFont = FontUtils.getChineseFont(14f);
//        Font smallFont = FontUtils.getChineseFont(12f);
//        Font titleFont = FontUtils.getChineseBoldFont(24f);
//
//        // 顶部面板
//        JPanel topPanel = new JPanel(new BorderLayout());
//        localIPLabel = new JLabel("本地IP: " + localIP, JLabel.LEFT);
//        localIPLabel.setFont(smallFont);
//        localIPLabel.setForeground(Color.BLUE);
//        topPanel.add(localIPLabel, BorderLayout.WEST);
//
//        JLabel titleLabel = new JLabel("IP Phone", JLabel.CENTER);
//        titleLabel.setFont(titleFont);
//        topPanel.add(titleLabel, BorderLayout.CENTER);
//
//        add(topPanel, BorderLayout.NORTH);
//
//        // 中心面板
//        JPanel centerPanel = new JPanel(new GridLayout(4, 2, 10, 10));
//        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
//
//        JLabel targetIPLabel = new JLabel("目标IP:");
//        targetIPLabel.setFont(normalFont);
//        centerPanel.add(targetIPLabel);
//
//        ipField = new JTextField();
//        ipField.setFont(normalFont);
//        centerPanel.add(ipField);
//
//        JLabel modeLabel = new JLabel("通信方式:");
//        modeLabel.setFont(normalFont);
//        centerPanel.add(modeLabel);
//
//        String[] modes = {"拨号通话", "音频消息"};
//        modeComboBox = new JComboBox<>(modes);
//        modeComboBox.setFont(normalFont);
//        modeComboBox.addActionListener(e -> updateUIForMode());
//        centerPanel.add(modeComboBox);
//
//        // 录音状态显示
//        centerPanel.add(new JLabel("")); // 空标签
//        recordingStatusLabel = new JLabel("", JLabel.CENTER);
//        recordingStatusLabel.setFont(normalFont);
//        recordingStatusLabel.setForeground(Color.RED);
//        centerPanel.add(recordingStatusLabel);
//
//        add(centerPanel, BorderLayout.CENTER);
//
//        // 底部按钮面板
//        JPanel buttonPanel = new JPanel(new FlowLayout());
//
//        recordButton = new JButton("开始录音");
//        recordButton.setFont(normalFont);
//        recordButton.setVisible(false);
//
//        connectButton = new JButton("连接");
//        connectButton.setFont(normalFont);
//
//        buttonPanel.add(recordButton);
//        buttonPanel.add(connectButton);
//
//        add(buttonPanel, BorderLayout.SOUTH);
//    }
//
//    private void updateUIForMode() {
//        String selectedMode = getSelectedMode();
//        if ("音频消息".equals(selectedMode)) {
//            recordButton.setVisible(true);
//            connectButton.setText("发送消息");
//            recordingStatusLabel.setText("点击开始录音");
//        } else {
//            recordButton.setVisible(false);
//            connectButton.setText("连接");
//            recordingStatusLabel.setText("");
//            isRecording = false;
//            hasRecorded = false;
//            recordButton.setText("开始录音");
//        }
//    }
//
//    // 修改：添加参数来区分是开始录音还是停止录音
//    public void setRecordingState(boolean recording, boolean hasRecordedAudio) {
//        isRecording = recording;
//        hasRecorded = hasRecordedAudio;
//
//        if (isRecording) {
//            recordButton.setText("停止录音");
//            recordingStatusLabel.setText("录音中...");
//            recordingStatusLabel.setForeground(Color.RED);
//        } else {
//            recordButton.setText("开始录音");
//            if (hasRecorded) {
//                recordingStatusLabel.setText("录音完成，点击发送");
//                recordingStatusLabel.setForeground(Color.BLUE);
//            } else {
//                recordingStatusLabel.setText("点击开始录音");
//                recordingStatusLabel.setForeground(Color.RED);
//            }
//        }
//    }
//
//    // Getters for user input
//    public String getRemoteIP() {
//        return ipField.getText().trim();
//    }
//
//    public String getSelectedMode() {
//        return (String) modeComboBox.getSelectedItem();
//    }
//
//    // 修改：检查是否有录制完成的音频
//    public boolean hasRecordedAudio() {
//        return hasRecorded;
//    }
//
//    public boolean isRecording() {
//        return isRecording;
//    }
//
//    // Action listeners
//    public void addConnectButtonListener(ActionListener listener) {
//        connectButton.addActionListener(listener);
//    }
//
//    public void addRecordButtonListener(ActionListener listener) {
//        recordButton.addActionListener(listener);
//    }
//
//    // Utility methods
//    public void showError(String message) {
//        JOptionPane.showMessageDialog(this, message, "错误", JOptionPane.ERROR_MESSAGE);
//    }
//
//    public void showInfo(String message) {
//        JOptionPane.showMessageDialog(this, message, "信息", JOptionPane.INFORMATION_MESSAGE);
//    }
//
//    public void clearFields() {
//        ipField.setText("");
//        recordingStatusLabel.setText("点击开始录音");
//        recordingStatusLabel.setForeground(Color.RED);
//        isRecording = false;
//        hasRecorded = false;
//        recordButton.setText("开始录音");
//    }
//
//    // 更新本地IP显示
//    public void updateLocalIP(String localIP) {
//        localIPLabel.setText("本地IP: " + localIP);
//    }
//
//    // 更新录音状态
//    public void setRecordingStatus(String status, Color color) {
//        recordingStatusLabel.setText(status);
//        recordingStatusLabel.setForeground(color);
//    }
//}
package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import util.FontUtils;

public class MainView extends JPanel {
    private JTextField ipField;
    private JComboBox<String> modeComboBox;
    private JButton connectButton;
    private JLabel localIPLabel;
    private JButton recordButton;
    private JLabel recordingStatusLabel;
    private JButton serverToggleButton;
    private JLabel serverStatusLabel;
    private boolean isRecording = false;
    private boolean hasRecorded = false;
    private boolean isServerRunning = false;

    public MainView(String localIP) {
        initializeUI(localIP);
    }

    private void initializeUI(String localIP) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        Font normalFont = FontUtils.getChineseFont(14f);
        Font smallFont = FontUtils.getChineseFont(12f);
        Font titleFont = FontUtils.getChineseBoldFont(24f);

        // 顶部面板
        JPanel topPanel = new JPanel(new BorderLayout());
        localIPLabel = new JLabel("本地IP: " + localIP, JLabel.LEFT);
        localIPLabel.setFont(smallFont);
        localIPLabel.setForeground(Color.BLUE);
        topPanel.add(localIPLabel, BorderLayout.WEST);

        JLabel titleLabel = new JLabel("IP Phone", JLabel.CENTER);
        titleLabel.setFont(titleFont);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // 中心面板
        JPanel centerPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        // 服务器状态
        centerPanel.add(new JLabel("服务器状态:"));
        serverStatusLabel = new JLabel("已停止", JLabel.LEFT);
        serverStatusLabel.setFont(normalFont);
        serverStatusLabel.setForeground(Color.RED);
        centerPanel.add(serverStatusLabel);

        // 目标IP
        JLabel targetIPLabel = new JLabel("目标IP:");
        targetIPLabel.setFont(normalFont);
        centerPanel.add(targetIPLabel);

        ipField = new JTextField();
        ipField.setFont(normalFont);
        centerPanel.add(ipField);

        // 通信方式
        JLabel modeLabel = new JLabel("通信方式:");
        modeLabel.setFont(normalFont);
        centerPanel.add(modeLabel);

        String[] modes = {"拨号通话", "音频消息"};
        modeComboBox = new JComboBox<>(modes);
        modeComboBox.setFont(normalFont);
        modeComboBox.addActionListener(e -> updateUIForMode());
        centerPanel.add(modeComboBox);

        // 录音状态
        centerPanel.add(new JLabel("录音状态:"));
        recordingStatusLabel = new JLabel("", JLabel.LEFT);
        recordingStatusLabel.setFont(normalFont);
        recordingStatusLabel.setForeground(Color.RED);
        centerPanel.add(recordingStatusLabel);

        add(centerPanel, BorderLayout.CENTER);

        // 底部按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout());

        serverToggleButton = new JButton("启动服务器");
        serverToggleButton.setFont(normalFont);
        serverToggleButton.setBackground(Color.GREEN);

        recordButton = new JButton("开始录音");
        recordButton.setFont(normalFont);
        recordButton.setVisible(false);

        connectButton = new JButton("连接");
        connectButton.setFont(normalFont);

        buttonPanel.add(serverToggleButton);
        buttonPanel.add(recordButton);
        buttonPanel.add(connectButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // 初始化状态
        updateUIForMode();
    }

    private void updateUIForMode() {
        String selectedMode = getSelectedMode();
        if ("音频消息".equals(selectedMode)) {
            recordButton.setVisible(true);
            connectButton.setText("发送消息");
            recordingStatusLabel.setText("点击开始录音");
        } else {
            recordButton.setVisible(false);
            connectButton.setText("连接");
            recordingStatusLabel.setText("");
            isRecording = false;
            hasRecorded = false;
            recordButton.setText("开始录音");
        }
    }

    public void setRecordingState(boolean recording, boolean hasRecordedAudio) {
        isRecording = recording;
        hasRecorded = hasRecordedAudio;

        if (isRecording) {
            recordButton.setText("停止录音");
            recordingStatusLabel.setText("录音中...");
            recordingStatusLabel.setForeground(Color.RED);
        } else {
            recordButton.setText("开始录音");
            if (hasRecorded) {
                recordingStatusLabel.setText("录音完成，点击发送");
                recordingStatusLabel.setForeground(Color.BLUE);
            } else {
                recordingStatusLabel.setText("点击开始录音");
                recordingStatusLabel.setForeground(Color.RED);
            }
        }
    }

    public void setServerState(boolean running) {
        isServerRunning = running;
        if (running) {
            serverToggleButton.setText("停止服务器");
            serverToggleButton.setBackground(Color.RED);
            serverStatusLabel.setText("运行中");
            serverStatusLabel.setForeground(Color.GREEN);
        } else {
            serverToggleButton.setText("启动服务器");
            serverToggleButton.setBackground(Color.GREEN);
            serverStatusLabel.setText("已停止");
            serverStatusLabel.setForeground(Color.RED);
        }
    }

    // Getters for user input
    public String getRemoteIP() {
        return ipField.getText().trim();
    }

    public String getSelectedMode() {
        return (String) modeComboBox.getSelectedItem();
    }

    public boolean hasRecordedAudio() {
        return hasRecorded;
    }

    public boolean isRecording() {
        return isRecording;
    }

    public boolean isServerRunning() {
        return isServerRunning;
    }

    // Action listeners
    public void addConnectButtonListener(ActionListener listener) {
        connectButton.addActionListener(listener);
    }

    public void addRecordButtonListener(ActionListener listener) {
        recordButton.addActionListener(listener);
    }

    public void addServerToggleListener(ActionListener listener) {
        serverToggleButton.addActionListener(listener);
    }

    // Utility methods
    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "错误", JOptionPane.ERROR_MESSAGE);
    }

    public void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "信息", JOptionPane.INFORMATION_MESSAGE);
    }

    public void clearFields() {
        ipField.setText("");
        recordingStatusLabel.setText("点击开始录音");
        recordingStatusLabel.setForeground(Color.RED);
        isRecording = false;
        hasRecorded = false;
        recordButton.setText("开始录音");
    }

    public void updateLocalIP(String localIP) {
        localIPLabel.setText("本地IP: " + localIP);
    }

    public void setRecordingStatus(String status, Color color) {
        recordingStatusLabel.setText(status);
        recordingStatusLabel.setForeground(color);
    }
}